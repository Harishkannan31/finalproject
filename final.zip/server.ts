import {app} from "./app";
require("dotenv").config();
import connectDB from "./utils/db";

// create server
app.listen(process.env.port,()=>{
    console.log(`server is connected to port ${process.env.PORT}`);
    connectDB();
});