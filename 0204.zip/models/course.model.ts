import mongoose,{Document,Model,Schema} from 'mongoose';
interface IComment extends Document{
    user:object,
    comment:string;
    commentReplies?:IComment[];
}

interface IReview extends Document{
    user:object;
    rating:number;
    comment:string;
    commentReplies:IComment[];
}

interface ILink extends Document{
    title:string;
    url:string;
}

interface IcourseData extends Document{
    title:string;
    description:string;
    videoUrl:string;
    videoThumbnail:object;
    videoSection:string;
    videoLength:number;
    videoPlayer:string;
    links:ILink[];
    suggestion:string;
    questions:IComment[];
}

interface ICourse extends Document{
    name:string;
    description:string;
    price:number;
    estimatedPrice?:number;
    thumbnail:object;
    tags:string;
    level:string;
    demoUrl:string;
    benefits:{title:string}[];
    prerequesites:{title:string}[];
    reviews:IReview[];
    courseData:IcourseData[];
    ratings?:number;
    purchased?:number;
}

const reviewSchema = new Schema<IReview>({
    user: Object,
    rating:{
        type:Number,
        default: 0,
    },
    comment:String,
});

const linkSchema = new Schema<ILink>({
    title:String,
    url:String,
});

const commentSchema = new Schema<IComment>({
    user:Object,
    comment:String,
    commentReplies: [Object],
});

const courseDataScheme = new Schema<IcourseData>({
    videoUrl:String,
    videoThumbnail:Object,
    title:String,
    videoSection:String,
    description:String,
    videoLength:Number,
    videoPlayer:String,
    links:[linkSchema],
    suggestion:String,
    questions:[commentSchema],
});

const courseSchema = new Schema<ICourse>({
    name:{
        type:String,
        required:true,
    },
    desc
})